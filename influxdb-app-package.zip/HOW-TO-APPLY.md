# How to apply this to naked-head/homeassistant-addons

This zip is meant to be extracted **on top of** your existing local clone
of `naked-head/homeassistant-addons`. It is not itself a repo — don't
commit this note file.

## New files (just add them)

```
influxdb/CHANGELOG.md
influxdb/DOCS.md
influxdb/Dockerfile
influxdb/README.md
influxdb/RELEASING.md
influxdb/config.yaml
influxdb/icon.png
influxdb/rootfs/etc/services.d/influxdb/finish
influxdb/rootfs/etc/services.d/influxdb/run
influxdb/test/scenarios/default.json
influxdb/test/scenarios/setup.json
influxdb/test/scenarios/setup-missing.json
influxdb/test/smoke.sh
influxdb/translations/en.yaml

.github/workflows/influxdb-build.yml
.github/workflows/influxdb-test.yml
.github/ISSUE_TEMPLATE/influxdb-bug-report.yml
```

## Modified files (overwrite the existing ones in your repo)

```
README.md                          — added the InfluxDB entry to the app list
.github/workflows/lint.yml         — added influxdb/config.yaml to the yamllint invocation
.github/ISSUE_TEMPLATE/config.yaml — added the InfluxDB-upstream contact link
```

Both are small, additive diffs — if you've made local changes to either
since I last read them, re-apply just the InfluxDB-related lines by hand
instead of overwriting wholesale.

## Unchanged (included only for local testing convenience)

```
test/mock/Dockerfile
test/mock/server.py
```

Identical to what's already in your repo — the InfluxDB smoke test reuses
the same shared Supervisor mock as BamBuddy and Bambu Studio API. You don't
need to copy these; they're only here so `./influxdb/test/smoke.sh` can be
run standalone by extracting just this zip somewhere, without a full clone.

## chmod after extracting

`run`/`finish`/`smoke.sh` need the executable bit, which zip doesn't
always preserve:

```bash
chmod +x influxdb/rootfs/etc/services.d/influxdb/run
chmod +x influxdb/rootfs/etc/services.d/influxdb/finish
chmod +x influxdb/test/smoke.sh
```
